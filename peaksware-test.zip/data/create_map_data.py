import json
import os

home = os.path.dirname(os.path.realpath(__file__))

with open(home + '/workout-data.json') as json_file:
    workout_data = json.load(json_file)

samples = workout_data['samples']
map_data = []

for sample in samples:

    time = sample['millisecondOffset']

    values = sample['values']
    latitude = values.get('positionLat', None)
    longitude = values.get('positionLong', None)

    if latitude and longitude:

        map_obj = {'lat': latitude, 'lng': longitude}
        map_data.append(map_obj)

with open('map-data.json', 'w') as outfile:
    json.dump(map_data, outfile)

