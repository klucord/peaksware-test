import json
import os

home = os.path.dirname(os.path.realpath(__file__))

with open(home + '/workout-data.json') as json_file:
    workout_data = json.load(json_file)

samples = workout_data['samples']
graph_data = []

for sample in samples:

    time = sample['millisecondOffset']

    values = sample['values']
    power = values.get('power', 0)

    graph_obj = {'time': time, 'power': power}

    graph_data.append(graph_obj)

with open('graph-data.json', 'w') as outfile:
    json.dump(graph_data, outfile)

