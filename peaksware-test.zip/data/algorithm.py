import json
import os

home = os.path.dirname(os.path.realpath(__file__))

with open(home + '/workout-data.json') as json_file:
    workout_data = json.load(json_file)

twenty_minutes = 60000

all_sessions = workout_data['samples']
split_sessions = []
new_session = []

for session in all_sessions:

    new_session.append(session)

    if session['eventType'] == 'stop':

        split_sessions.append(new_session)
        new_session = []
        all_sessions.pop(0)

highest_average_power = 0
highest_millisecond_offset = 0
session_highest_average_power = 0
session_highest_millisecond_offset = 0

for individual_session in split_sessions:

    if session_highest_average_power >= highest_average_power:
        highest_average_power = session_highest_average_power
        highest_millisecond_offset = session_highest_millisecond_offset

    indexed_samples = individual_session
    session_highest_average_power = 0
    session_highest_millisecond_offset = 0

    while indexed_samples:

        samples = indexed_samples
        interval_total_millisecond = 0
        millisecond_this_far = 0
        total_millisecond = 0
        data_points = 0
        power = 0

        for sample in samples:

            millisecond_offset = sample['millisecondOffset']
            total_millisecond = total_millisecond + millisecond_offset

            interval_millisecond_offset = millisecond_offset - millisecond_this_far
            interval_total_millisecond = interval_total_millisecond + interval_millisecond_offset

            power = power + sample['values'].get('power', 0)
            data_points += 1

            if interval_total_millisecond >= twenty_minutes:

                average_power = (power/data_points)

                if average_power >= session_highest_average_power:
                    session_highest_average_power = average_power
                    session_highest_millisecond_offset = millisecond_offset

                data_points = 0
                power = 0
                interval_total_millisecond = 0
                millisecond_this_far = total_millisecond

        indexed_samples.pop(0)

print ''
print 'highest average power: ' + str(highest_average_power)
print 'start time of highest average power: ' + str(highest_millisecond_offset - twenty_minutes)
print 'end time of highest average power: ' + str(highest_millisecond_offset)



